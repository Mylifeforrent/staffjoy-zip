package xyz.staffjoy.common.validation;

public interface Group2 {
}
