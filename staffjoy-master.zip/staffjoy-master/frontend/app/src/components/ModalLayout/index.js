import ModalLayoutSingleColumn from './SingleColumn';
import ModalLayoutRightSideColumn from './RightSideColumn';

export {
  ModalLayoutSingleColumn,
  ModalLayoutRightSideColumn,
};
