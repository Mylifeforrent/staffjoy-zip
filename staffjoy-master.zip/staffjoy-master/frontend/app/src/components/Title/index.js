import React from 'react';

function Title() {
  return (
    <div>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <h1>Yo</h1>
      <a href="/scheduling">click here</a>
    </div>
  );
}

function OtherTitle() {
  return (
    <div>
      <h1>Sup</h1>
    </div>
  );
}

module.exports = {
  Title,
  OtherTitle,
};
