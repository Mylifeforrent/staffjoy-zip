package xyz.staffjoy.faraday;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaradayApplication {
    public static void main(String[] args) {
        SpringApplication.run(FaradayApplication.class, args);
    }
}
