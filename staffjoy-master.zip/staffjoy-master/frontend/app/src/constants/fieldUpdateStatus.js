export const ERROR = 'ERROR';
export const SUCCESS = 'SUCCESS';
export const UPDATING = 'UPDATING';
