version 1.2.1
This release [has been modified](https://github.com/Staffjoy/staffjoy/commit/f134ba705ff3fa15ae0d3d1b0f633ec25e80348d) to work with the [React-MDL library](https://tleunen.github.io/react-mdl/) and their functional implementation of the Layout Container.
