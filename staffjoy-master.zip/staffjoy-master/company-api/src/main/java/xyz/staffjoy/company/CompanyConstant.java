package xyz.staffjoy.company;

public class CompanyConstant {

    public static final String SERVICE_NAME = "company-service";

}
