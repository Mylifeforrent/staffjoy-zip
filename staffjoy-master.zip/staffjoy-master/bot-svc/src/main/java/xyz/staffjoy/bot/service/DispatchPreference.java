package xyz.staffjoy.bot.service;

enum DispatchPreference {
    DISPATCH_SMS,
    DISPATCH_EMAIL,
    DISPATCH_UNAVAILABLE
}