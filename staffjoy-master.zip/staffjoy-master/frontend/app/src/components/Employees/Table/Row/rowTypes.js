export const PHOTO_NAME = 'PHOTO_NAME';
export const CONTACT_INFO = 'CONTACT_INFO';
export const INFO_LIST = 'INFO_LIST';
export const BOOLEAN_LABEL = 'BOOLEAN_LABEL';
