export const MILISECONDS_TO_SECONDS = 1000.0;
export const WEEK_LENGTH = 7;
